# PGDAS-D x XML Auditing System

## Overview

A specialized Python FastAPI web application for Brazilian tax auditing that automates the comparison between PGDAS-D (Programa Gerador do Documento de Arrecadação do Simples Nacional e Declaração) declarations and XML files from NF-e (Nota Fiscal Eletrônica). The system identifies discrepancies in the taxation of goods under the 'monofásico' (single-phase) tax regime for PIS/COFINS, calculating potential tax overpayments and generating audit reports and legal documents for tax restitution claims.

## Business Purpose

This system helps Brazilian businesses under the Simples Nacional tax regime to:
- Identify products that were incorrectly taxed under regular PIS/COFINS when they should have been subject to the monofásico regime
- Calculate potential tax overpayments automatically
- Generate professional audit reports and legal petition templates
- Streamline the tax restitution process with automated documentation

## System Architecture

**Backend:** FastAPI (Python) web application with:
- RESTful API endpoints for file uploads and audit processing
- Jinja2 templates for HTML rendering
- SQLAlchemy ORM with SQLite database
- Automated audit workflow processing

**Database:** SQLite with the following main entities:
- `Empresa` - Company registration data (CNPJ, business name, etc.)
- `NotaFiscal` - Invoice header information (number, date, totals)
- `ItemNota` - Invoice line items (NCM codes, tax codes, values)
- `CompetenciaPGDAS` - Monthly PGDAS-D declarations (revenues, tax rates)
- `NCMMonofasico` - Reference table of NCM codes subject to monofásico regime
- `AnexoAliquota` - Simples Nacional tax rate tables by annex and revenue range
- `ResultadoAuditoria` - Audit results (base comparisons, calculated overpayments)

**Key Services:**
- `xml_parser.py` - Parses NF-e XML files and extracts tax data
- `pgdas_importer.py` - Imports PGDAS-D CSV declarations
- `rules_engine.py` - Classifies items by NCM/CST codes, calculates monofásico bases
- `comparison.py` - Compares XML-derived bases against PGDAS-D declarations
- `calculator.py` - Estimates undue PIS/COFINS amounts using effective tax rates
- `reports.py` - Generates Excel audit reports (summaries, NCM details, inconsistencies)
- `petition_generator.py` - Creates HTML legal petition templates for tax restitution

## Main Features

### 1. File Upload & Processing
- Web interface for uploading NF-e XML files and PGDAS-D CSV exports
- Automatic parsing and database import
- Support for multiple files and competence periods

### 2. Automated Tax Classification
- NCM-based identification of monofásico products
- CST code validation (typically CST 04 for monofásico items)
- Flagging of inconsistencies in tax treatment
- Date-based validation of NCM regime applicability

### 3. Base Comparison & Calculation
- Automatic comparison of monofásico bases: XML vs PGDAS-D
- Calculation of base differences (XML - PGDAS-D)
- Estimation of undue PIS/COFINS using effective tax rates
- Support for all Simples Nacional annexes and revenue ranges

### 4. Report Generation
- **Summary Report**: Overview by competence with totals
- **NCM Detail Report**: Breakdown by NCM code with volumes and values
- **Inconsistency Report**: List of items with tax coding issues
- All reports generated in Excel format for easy analysis

### 5. Legal Documentation
- Automated "peça espelho" (mirror document) generation in HTML
- Template for PGDAS-D rectification requests
- Template for PIS/COFINS restitution claims
- Professional formatting ready for legal review

## Technical Implementation

**Frontend:**
- Jinja2 templates for HTML rendering
- Simple CSS styling served from `/static`
- Form-based file upload interface

**Backend:**
- FastAPI framework with dependency injection
- SQLAlchemy ORM for type-safe database operations
- Pandas for Excel report generation
- Decimal precision for financial calculations
- Transaction-based processing with proper commit/rollback

**File Storage:**
- Uploaded XMLs stored in `uploads/xmls/`
- Uploaded PGDAS CSVs stored in `uploads/pgdas/`
- Generated reports in `relatorios/`
- Generated petitions in `pecas/`
- Database file in `data/auditoria_monofasico.db`

**API Endpoints:**
- `GET /` - Home page with upload form
- `POST /processar` - Process uploaded files and run audit
- `GET /health` - Health check endpoint
- Static file serving for reports and petitions

## Audit Workflow

1. **Upload Phase**
   - User uploads NF-e XML files (one or multiple)
   - User uploads PGDAS-D CSV export files
   - System saves files to appropriate directories

2. **Import Phase**
   - XML parser extracts invoice and item data
   - PGDAS importer loads declaration data
   - All data persisted to SQLite database

3. **Classification Phase**
   - Rules engine processes each invoice item
   - NCM codes matched against monofásico reference table
   - CST codes validated for consistency
   - Items flagged as monofásico or inconsistent

4. **Comparison Phase**
   - Calculate total monofásico base from XMLs per competence
   - Compare against declared monofásico base in PGDAS-D
   - Store base differences in audit results

5. **Calculation Phase**
   - Retrieve effective tax rates from PGDAS-D and annexes
   - Calculate PIS percentage of effective rate
   - Calculate COFINS percentage of effective rate
   - Estimate undue amounts: difference × effective rate × percentage

6. **Reporting Phase**
   - Generate Excel summary by competence
   - Generate Excel NCM detail report
   - Generate Excel inconsistency list
   - Generate HTML legal petition template

7. **Results Phase**
   - Display summary in web interface
   - Provide download links for all reports
   - Provide download link for petition document

## Running the Application

**Development:**
```bash
uvicorn app.main:app --host 0.0.0.0 --port 5000 --reload
```

**Access:**
- Application runs on port 5000
- Main interface: `http://localhost:5000`
- Health check: `http://localhost:5000/health`

## Data Model Details

**Empresa (Company)**
- CNPJ (unique identifier)
- Razão Social, Nome Fantasia
- CNAE code, Simples Nacional dates

**NotaFiscal (Invoice)**
- Chave (44-digit access key - unique)
- Number, series, dates
- Emitter/recipient CNPJs
- Total value, destination state

**ItemNota (Invoice Item)**
- NCM (product classification code)
- CFOP (fiscal operation code)
- CST PIS/COFINS (tax situation codes)
- Quantities, values
- PIS/COFINS bases and amounts
- Flags: `eh_monofasico`, `eh_inconsistente`

**CompetenciaPGDAS (Monthly Declaration)**
- ano_mes (YYYY-MM format)
- Annex (I, II, III, IV, or V)
- Total gross revenue
- Declared monofásico revenue
- 12-month rolling revenue
- Nominal and effective tax rates

**ResultadoAuditoria (Audit Result)**
- base_monofasica_xml (calculated from XMLs)
- base_monofasica_pgdas (from declaration)
- diferenca_base (XML - PGDAS)
- pis_indev, cofins_indev, total_indev (estimated overpayments)

## User Preferences

- Communication style: Simple, everyday language
- Focus on automation and accuracy
- Clear error messages and validation

## Recent Changes

- 2025-11-28: Migrated from Node.js configuration to Python FastAPI
- 2025-11-28: Installed Python 3.11 and required dependencies
- 2025-11-28: Fixed SQLAlchemy 2.0 compatibility with `__allow_unmapped__`
- 2025-11-28: Created required directories (static, templates, uploads, reports, petitions)
- 2025-11-28: Configured workflow to run uvicorn on port 5000
- 2025-11-28: Application successfully running and serving requests

## External Dependencies

**Python Packages:**
- `fastapi` - Web framework
- `uvicorn` - ASGI server
- `sqlalchemy` - ORM and database toolkit
- `python-multipart` - File upload support
- `jinja2` - Template engine
- `pandas` - Excel report generation
- `jsonschema` - Schema validation
- `bcrypt` - Password hashing (for future auth features)

**Development Tools:**
- `uv` - Python package manager
- SQLite - Embedded database
- Python 3.11 - Runtime environment

## Future Enhancements

- User authentication and multi-user support
- Company management dashboard
- Historical audit tracking
- Batch processing for large file sets
- API endpoints for programmatic access
- PDF report generation alongside Excel
- Integration with e-CAC for automatic PGDAS-D retrieval
- Integration with SEFAZ for automatic NF-e download
